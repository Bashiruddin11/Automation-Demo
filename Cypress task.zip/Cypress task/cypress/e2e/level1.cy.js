describe('Upwork Login Error Message', () => {


  Cypress.on('uncaught:exception', (err, runnable) => {
    // returning false here prevents Cypress from
    // failing the test
    return false
  })
    it('Displays error message for invalid email', () => {
      // Visit the URL
      cy.visit("https://www.freelancer.com/")
  
      // Click on the login link
      cy.get('[fltrackinglabel="LoginPage"] > .LinkElement').click();  
      // Enter invalid email and click continue
      cy.get('#emailOrUsernameInput').type('invalidemail@example') //email
      cy.get('#passwordInput').type('dsdsds') //password
      cy.get('app-login-signup-button > fl-button > .ButtonElement').click(); //click on button
      cy.get('.BannerAlertBox-desc > .NativeElement').should('contain.text','Incorrect email, username or password.')
  
      
    })
  })
  