describe('Upwork Login Error Message', () => {


    Cypress.on('uncaught:exception', (err, runnable) => {
      // returning false here prevents Cypress from
      // failing the test
      return false
    })
      it('level2', () => {
        // Visit the URL
        cy.visit("https://www.freelancer.com/")
    
        // Click on the login link
        cy.get('[fltrackinglabel="LoginPage"] > .LinkElement').click();  
        // Enter invalid email and click continue
        cy.get('#emailOrUsernameInput').type('invalidemail@example') //email
        cy.get('app-login-signup-button > fl-button > .ButtonElement').click(); //click on button
        cy.get('.ErrorContainer').should('contain.text','Please enter your password')
    
        
      })
    })
    